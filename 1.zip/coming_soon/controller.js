(function(angular) {
    'use strict';
    var module = angular.module('douban.coming_soon', [
        'myservice'
        ]);
    //配置路由
    module.config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/coming_soon/:page', {
            templateUrl: '../in_theaters/view.html',
            controller: 'in_theatersController'
        })
    }]);
    /*写控制器*/
    module.controller('in_theatersController', [
        '$scope',
        '$route',
        '$routeParams',
         'httpService',
         function($scope,$route,$routeParams, httpService) {
              var count = 10;
             var page = parseInt($routeParams.page);
             var start = (page-1)*count;
             console.log(page)

        $scope.error = '';
        $scope.data = [ ];

        $scope.zongyeshu = 0;
        $scope.page = 0;
        /*跨域请求数据*/
        httpService.jsonp('https://api.douban.com/v2/movie/in_theaters', {
            start : start,
          count:count
        }, function(data) {
              $scope.data = data;
            
               console.log(data)
                 $scope.zongyeshu = Math.ceil(data.total / 10);
          $scope.page = page;
             $scope.$apply();
        })
       /*暴露行为gopage*/
       $scope.goPage =function(page){
         if(page>=1&&page<=$scope.zongyeshu){
            $route.updateParams({page:page})
             }       
       }
    }])

})(angular);

/* $http.get('in_theaters/in_theaters.json').then(function(data){
            console.log(data);
            if(data.status == 200){
                $scope.data = data.data;
            }else{
                $scope.error = '数据请求失败!!!'+data.statusText;
            }
        },function(err){
            $scope.error = '数据请求失败!!!'+err.statusText;
        })*/