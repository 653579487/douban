(function(angular){
    'use strict';
    /*ģ��*/
    var module = angular.module('douban.top',[]);
    /*·��*/
    module.config(['$routeProvider',function($routeProvider){
        $routeProvider.when('/top250',{
            templateUrl:'top250/view.html',
            controller:'inTop'
        })
    }]);
    /*������*/
    module.controller('inTop',['$scope',function($scope){

    }])
})(angular);